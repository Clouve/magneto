# feed
Offers a unified feed of latest posts from student and class websites to staff, parents and students.
