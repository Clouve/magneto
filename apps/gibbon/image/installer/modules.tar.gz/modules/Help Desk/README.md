Gibbon Help Desk Module
========

A Gibbon Help Desk Module by Ray Clark, Ashton Power and Adrien Tremblay.

This is a semi-stable developmental branch, with code updates by Ashton Power & Ray Clark.

Currently the Module is currently undergoing large scale refactoring and as a result may have some instabilities. We ask you to be patient and report any bugs you may find in the system.
