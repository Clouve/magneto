# module-awards
The Awards module allows a school to define and assign a range of awards to students. Awards can recognise, for example, academic, social or athletic achievement or progress.
