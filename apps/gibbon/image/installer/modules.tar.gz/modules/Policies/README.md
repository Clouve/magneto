module-policies
===============
Requires Core v17.0.00 or greater


INSTALL/UPGRADE
===============
1. After downloading and unzipping, rename the module folder to "Policies".
2. Upload the file to the /modules folder on your server.
3. Log in to Gibbon and use System Admin > Manage Modules to install/update.

